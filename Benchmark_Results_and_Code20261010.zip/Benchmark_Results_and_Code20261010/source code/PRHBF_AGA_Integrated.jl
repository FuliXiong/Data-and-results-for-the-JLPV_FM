
# ===================================================================
# PRHBF_AGA_Integrated.jl
# Adaptive Genetic Algorithm (AGA) with VNS for PRHBF problem
# Integrates: skyline bin packing, group-to-mold assignment,
#             group sequencing, and vehicle routing
# ===================================================================

using JLD2, Statistics, DataFrames, Random
using JuMP, CSV, Dates
using Gurobi








if !@isdefined(SCRIPT_DIR)
    global SCRIPT_DIR = @__DIR__
end
if !@isdefined(TUNING_DIR)
    global TUNING_DIR = joinpath(SCRIPT_DIR, "..", "tuning_irace", "R", "results")
end

function load_tuning_params()
    try
        params_aga = CSV.File(joinpath(TUNING_DIR, "PRHBF_AGA", "best_params_PRHBF_AGA.csv")) |> first
        return (
            max_iteration = params_aga.max_iteration,
            pop_size = params_aga.pop_size,
            k1 = params_aga.k1,
            k2 = params_aga.k2,
            k3 = params_aga.k3,
            k4 = params_aga.k4,
            T_para = haskey(params_aga, :T_para) ? params_aga.T_para : 1.0
        )
    catch e
        @warn "无法读取调参参数文件，使用默认参数: $e"
        return (
            max_iteration = 63,
            pop_size = 40,
            k1 = 0.8,
            k2 = 0.5,
            k3 = 0.8,
            k4 = 0.5,
            T_para = 1.0
        )
    end
end

if !@isdefined(params_aga)
    global params_aga = load_tuning_params()
end
if !@isdefined(maxIter_tuning)
    global maxIter_tuning = params_aga.max_iteration
end
if !@isdefined(popSize_tuning)
    global popSize_tuning = params_aga.pop_size
end
if !@isdefined(k1_tuning)
    global k1_tuning = params_aga.k1
end
if !@isdefined(k2_tuning)
    global k2_tuning = params_aga.k2
end
if !@isdefined(k3_tuning)
    global k3_tuning = params_aga.k3
end
if !@isdefined(k4_tuning)
    global k4_tuning = params_aga.k4
end
if !@isdefined(T_para_tuning)
    global T_para_tuning = params_aga.T_para
end




# ===================================================================
# Data structures for skyline bin packing
# ===================================================================

mutable struct SkylineSegment
    x::Int; width::Int; height::Int
end

mutable struct RectangleItem
    index::Int; width::Int; height::Int; rotated::Bool
end

mutable struct PackingItem
    id::Int; width::Int; height::Int
end

mutable struct PackingBin
    width::Int; height::Int
    items::Vector{Tuple{PackingItem,Tuple{Int,Int}}}
    remaining_width::Int; remaining_height::Int
end

PackingBin(width::Int, height::Int) = PackingBin(width, height, [], width, height)

# ===================================================================
# Bin packing: Best Fit (skyline) algorithm
# ===================================================================

# Check if an item can be placed at (x,y) without overlapping existing items
function can_place(bin::PackingBin, item::PackingItem, position::Tuple{Int,Int})
    x, y = position
    x + item.width <= bin.width && y + item.height <= bin.height || return false
    for (pi, pp) in bin.items
        px, py = pp
        x < px + pi.width && x + item.width > px &&
        y < py + pi.height && y + item.height > py && return false
    end
    true
end

place_item!(bin::PackingBin, item::PackingItem, position::Tuple{Int,Int}) =
    push!(bin.items, (item, position))

function find_position_skyline(bin::PackingBin, item::PackingItem)
    for y in 0:(bin.height - item.height)
        for x in 0:(bin.width - item.width)
            can_place(bin, item, (x, y)) && return (x, y)
        end
    end
    nothing
end




# Merge adjacent skyline segments with equal heights
function merge_adjacent_segments(segments::Vector{SkylineSegment})
    isempty(segments) && return segments
    merged = SkylineSegment[]; current = segments[1]
    for i in 2:length(segments)
        if segments[i].height == current.height
            current = SkylineSegment(current.x, current.width + segments[i].width, current.height)
        else
            push!(merged, current); current = segments[i]
        end
    end
    push!(merged, current); merged
end

# Place a rectangle on the skyline and update segments
function place_rectangle_on_skyline(
    segments::Vector{SkylineSegment}, item_w::Int, item_h::Int, x_pos::Int)
    new_segments = SkylineSegment[]
    cur_x = 0; seg_idx = 0
    for (i, seg) in enumerate(segments)
        if x_pos >= cur_x && x_pos < cur_x + seg.width
            seg_idx = i; break
        end
        cur_x += seg.width
    end
    seg_idx == 0 && (seg_idx = length(segments))
    left_w = x_pos - cur_x
    right_w = segments[seg_idx].width - left_w - item_w
    for i in 1:(seg_idx-1); push!(new_segments, segments[i]); end
    if left_w > 0
        push!(new_segments, SkylineSegment(segments[seg_idx].x, left_w, segments[seg_idx].height))
    end
    push!(new_segments, SkylineSegment(x_pos, item_w, segments[seg_idx].height + item_h))
    if right_w > 0
        push!(new_segments, SkylineSegment(x_pos + item_w, right_w, segments[seg_idx].height))
    end
    for i in (seg_idx+1):length(segments); push!(new_segments, segments[i]); end
    merge_adjacent_segments(new_segments)
end








# Full skyline Best Fit bin packing: given item order (ran), compute layout and bin assignment
function bfp_packing(Item, ran, pallet_width, pallet_height)
    itemNum = size(Item, 1)
    ansBXY = zeros(Int, itemNum, 6)
    result = zeros(Int, itemNum, 2)
    rotated = zeros(Int, itemNum)
    placed = Vector{Tuple{Int,Int,Int,Int,Int,Int}}()

    
    R = RectangleItem[]
    for i in ran
        w, h = Item[i,1], Item[i,2]; rf = false
        if h > w; w, h = h, w; rf = true; end
        push!(R, RectangleItem(i, w, h, rf))
    end

    bin_num = 0
    pallet_area = pallet_width * pallet_height

    while !isempty(R)
        bin_num += 1
        skyline = [SkylineSegment(0, pallet_width, 0)]

        
        
        
        
        L = RectangleItem[]
        total_area = 0
        idx = 1
        while idx <= length(R) && total_area < pallet_area
            total_area += R[idx].width * R[idx].height
            push!(L, R[idx])
            idx += 1
        end

        
        for r in L
            if r.height > r.width
                r.width, r.height = r.height, r.width
                r.rotated = !r.rotated
            end
        end
        sort!(L, by=r -> (-r.width, -r.height))

        
        for r in L
            rmi = findfirst(x -> x.index == r.index, R)
            if rmi !== nothing
                deleteat!(R, rmi)
            end
        end

        
        
        
        while !isempty(L)
            
            min_seg_idx = 0
            min_seg_h = typemax(Int)
            for (i, seg) in enumerate(skyline)
                if seg.height < min_seg_h
                    min_seg_h = seg.height
                    min_seg_idx = i
                end
            end

            seg = skyline[min_seg_idx]
            gap_h = seg.height
            gap_x = seg.x
            avail_w = seg.width
            avail_h = pallet_height - gap_h

            sky_dif = pallet_height - min_seg_h  

            
            hwmin = minimum(min(r.height, r.width) for r in L)

            
            if sky_dif < hwmin
                
                reverse!(L)  
                for r in L
                    insert!(R, 1, r)
                end
                break  
            end

            
            best_rect = nothing
            best_idx = 0
            best_score = -1  

            for (idx, r) in enumerate(L)
                if r.width <= avail_w && r.height <= avail_h
                    
                    score = r.width * r.height
                    if score > best_score
                        best_score = score
                        best_rect = r
                        best_idx = idx
                    end
                end
            end

            if best_rect !== nothing
                
                push!(placed, (best_rect.index, gap_x, gap_h,
                    best_rect.width, best_rect.height,
                    best_rect.rotated ? 1 : 0))
                ansBXY[best_rect.index, :] =
                    [bin_num, best_rect.index, best_rect.width,
                     best_rect.height, gap_x, gap_h]
                rotated[best_rect.index] = best_rect.rotated ? 1 : 0
                result[best_rect.index, :] = [best_rect.index, bin_num]

                deleteat!(L, best_idx)

                skyline = place_rectangle_on_skyline(skyline,
                    best_rect.width, best_rect.height, gap_x)
            else
                
                
                if avail_w > 0 && avail_h > 0
                    skyline = place_rectangle_on_skyline(skyline, avail_w, avail_h, gap_x)
                end
            end
        end
    end

    
    boxes_dict = Dict{Int,Vector{Any}}()
    for b in 1:bin_num; boxes_dict[b] = []; end
    for i in 1:itemNum
        b = ansBXY[i,1]
        if b > 0; push!(boxes_dict[b], (Item[result[i,1],:], ran[i])); end
    end

    bin_of = [ansBXY[i,1] for i in 1:itemNum]
    sorted_idx = sortperm(bin_of)
    final_result = zeros(Int, itemNum, 2)
    for (pos, i) in enumerate(sorted_idx)
        final_result[pos, 1] = result[i, 1]
        final_result[pos, 2] = result[i, 2]
    end

    wasted_space = 0
    return boxes_dict, ansBXY, ran, bin_num, final_result, rotated, wasted_space
end


const skyline_bf_packing_v2 = bfp_packing

# Fast packing: shuffle items, pack via skyline BF, return bin objects
function fast_packing_algorithm(items::Vector{PackingItem}, bin_width::Int, bin_height::Int)
    items = shuffle(items)
    J = length(items)
    Item_matrix = zeros(Int, J, 2)
    for (idx, item) in enumerate(items)
        Item_matrix[idx,1] = item.width; Item_matrix[idx,2] = item.height
    end
    ran = shuffle(1:J)
    boxes_dict, ansBXY, ran_out, BinNum, result, rotated, wasted_space =
        skyline_bf_packing_v2(Item_matrix, ran, bin_width, bin_height)
    bins = PackingBin[]
    for bin_id in 1:BinNum
        bin = PackingBin(bin_width, bin_height)
        for i in 1:size(ansBXY,1)
            if ansBXY[i,1] == bin_id
                item_id = ansBXY[i,2]; w = ansBXY[i,3]; h = ansBXY[i,4]
                x = ansBXY[i,5]; y = ansBXY[i,6]
                item = PackingItem(item_id, w, h)
                place_item!(bin, item, (x, y))
            end
        end
        push!(bins, bin)
    end
    bins
end

# Print all items in all bins as (item_id, bin_id) pairs
function print_bins(bins::Vector{PackingBin})
    result = []
    for (i, bin) in enumerate(bins)
        for (item, position) in bin.items
            push!(result, [item.id, i])
        end
    end
    result
end

# Compute mold area utilization
calculate_utilization(placed, pallet_width, pallet_height) =
    sum(p[4]*p[5] for p in placed; init=0.0) / (pallet_width * pallet_height)

const packing_algorithm = skyline_bf_packing_v2
const Item = PackingItem
const Bin = PackingBin





# Best Fit skyline packing driven by a job sequence
function packing_by_sequence_aga(items, seq, WW::Int, HH::Int)
    if isempty(seq)
        ran = shuffle(1:size(items, 1))
        return packing_algorithm(items, ran, WW, HH)
    else
        return packing_algorithm(items, seq, WW, HH)
    end
end





# ===================================================================
# Scheduling: makespan calculation
# ===================================================================

# Calculate makespan given group sequencing on molds
# Returns: per-group completion times, per-mold makespans, overall makespan
function makespan(p, G, W, mold_to_groups, group_to_mold, sequence_chromosome, ptr_time)
    phase2_complete_global = 0.0
    phase3_finish = zeros(Float64, G)
    ct = zeros(Float64, G)

    for g in sequence_chromosome
        if g < 1 || g > G
            continue
        end

        mold = group_to_mold[g]
        mold_groups_list = mold_to_groups[mold]
        g_idx_in_mold = findfirst(==(g), mold_groups_list)

        if g_idx_in_mold == 1
            phase1_start = 0.0
        else
            prev_group = mold_groups_list[g_idx_in_mold - 1]
            phase1_start = phase3_finish[prev_group]
        end

        phase1_complete = phase1_start + p[g, 1]
        phase2_start = max(phase1_complete, phase2_complete_global)
        phase2_complete = phase2_start + p[g, 2]
        phase2_complete_global = phase2_complete
        phase3_complete = phase2_complete + p[g, 3]
        phase3_finish[g] = phase3_complete
        ct[g] = phase3_complete + ptr_time
    end

    C = zeros(Float64, W)
    for mold in 1:W
        if haskey(mold_to_groups, mold) && !isempty(mold_to_groups[mold])
            C[mold] = maximum(ct[g] for g in mold_to_groups[mold])
        end
    end

    MK = maximum(C)
    return ct, C, MK
end





# ===================================================================
# Scheduling: Total Weighted Tardiness (TWT) evaluation
# ===================================================================

# Compute TWT given group sequencing and packing result
function TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, tal_sol, v_result, ptr_time; verbose::Bool=false)
    ct, C, MK = makespan(p, G, W, mold_to_groups, group_to_mold, tal_sol, ptr_time)

    if isempty(ct) || any(isnan, ct) || any(isinf, ct)
        return Inf
    end

    ct_jobs = zeros(Int64, J)
    for pair in v_result
        job_id = pair[1]
        group_id = pair[2]
        if group_id <= length(ct)
            ct_jobs[job_id] = Int(ct[group_id])
        end
    end

    T = zeros(Int64, J)
    late_jobs = 0
    total_delay = 0
    for j in 1:J
        T[j] = ct_jobs[j] - d[j]
        if T[j] < 0
            T[j] = 0
        else
            late_jobs += 1
            total_delay += T[j]
        end
    end

    del_punish = sum(beta[j] * T[j] for j in 1:J)
    return del_punish
end






# ===================================================================
# Mold assignment: local search (swap group between molds)
# ===================================================================

# Iteratively improve group-to-mold assignment to reduce TWT
function mold_assignment_local_search!(
    group_to_mold,
    mold_to_groups,
    mold_load,
    p,
    G,
    W_num,
    beta,
    d,
    J,
    v_result,
    ptr_time;
    max_iterations::Int=50
)
    if G < 2 || W_num < 2
        return
    end
    
    
    initial_seq = collect(1:G)
    
    
    current_twt = TWT(beta, d, p, J, G, W_num, mold_to_groups, group_to_mold, reshape(initial_seq, 1, length(initial_seq)), v_result, ptr_time)
    
    for iter in 1:max_iterations
        improved = false
        
        
        for g in 1:G
            current_mold = group_to_mold[g]
            
            
            for target_mold in 1:W_num
                if target_mold == current_mold
                    continue
                end
                
                
                old_mold = current_mold
                
                
                group_to_mold[g] = target_mold
                
                
                if !haskey(mold_to_groups, old_mold)
                    mold_to_groups[old_mold] = []
                end
                filter!(x -> x != g, mold_to_groups[old_mold])
                if !haskey(mold_to_groups, target_mold)
                    mold_to_groups[target_mold] = []
                end
                push!(mold_to_groups[target_mold], g)
                
                
                mold_load[old_mold] -= p[g, 1]
                mold_load[target_mold] += p[g, 1]
                
                
                new_twt = TWT(beta, d, p, J, G, W_num, mold_to_groups, group_to_mold, reshape(initial_seq, 1, length(initial_seq)), v_result, ptr_time)
                
                if new_twt < current_twt - 1e-6  
                    current_twt = new_twt  
                    improved = true
                    
                else
                    
                    group_to_mold[g] = old_mold
                    if !haskey(mold_to_groups, target_mold)
                        mold_to_groups[target_mold] = []
                    end
                    filter!(x -> x != g, mold_to_groups[target_mold])
                    if !haskey(mold_to_groups, old_mold)
                        mold_to_groups[old_mold] = []
                    end
                    push!(mold_to_groups[old_mold], g)
                    mold_load[old_mold] += p[g, 1]
                    mold_load[target_mold] -= p[g, 1]
                end
            end
        end
        
        if !improved
            break  
        end
    end
end




# ===================================================================
# GA operators: mutation
# ===================================================================

# Swap mutation: swap two genes in both sequence and allocation chromosomes
function swap_mutation(seq_chromosome, alloc_chromosome)
    n = length(seq_chromosome)
    i, j = rand(1:n, 2)
    if i != j
        seq_chromosome[i], seq_chromosome[j] = seq_chromosome[j], seq_chromosome[i]
        alloc_chromosome[i], alloc_chromosome[j] = alloc_chromosome[j], alloc_chromosome[i]
    end
    return seq_chromosome, alloc_chromosome
end

function swap_mutation1(seq_chromosome)
    n = length(seq_chromosome)
    i, j = rand(1:n, 2)
    if i != j
        seq_chromosome[i], seq_chromosome[j] = seq_chromosome[j], seq_chromosome[i]
    end
    return seq_chromosome
end

function insert_mutation1(seq_chromosome)
    n = length(seq_chromosome)
    i, j = rand(1:n, 2)
    if i != j
        seq_elem = splice!(seq_chromosome, i)[1]
        insert!(seq_chromosome, j, seq_elem)
    end
    return seq_chromosome
end

function reverse_mutation1(seq_chromosome)
    n = length(seq_chromosome)
    i, j = sort(rand(1:n, 2))
    if i != j
        seq_chromosome[i:j] = reverse(seq_chromosome[i:j])
    end
    return seq_chromosome
end





# ===================================================================
# VNS: Variable Neighborhood Search for group sequencing
# Neighborhoods: swap, insert, reverse
# ===================================================================

function VNS(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time, seq_chromosome)
    if G < 2
        TWT_VALUE = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(seq_chromosome, 1, length(seq_chromosome)), v_result, ptr_time)
        return copy(seq_chromosome), TWT_VALUE
    end

    k = 1
    TWT_VALUE = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(seq_chromosome, 1, length(seq_chromosome)), v_result, ptr_time)

    best_seq_chromosome = copy(seq_chromosome)
    new_seq_chromosome = copy(seq_chromosome)

    while k <= 3
        if k == 1
            new_seq_chromosome = swap_mutation1(copy(best_seq_chromosome))
        elseif k == 2
            new_seq_chromosome = insert_mutation1(copy(best_seq_chromosome))
        else
            new_seq_chromosome = reverse_mutation1(copy(best_seq_chromosome))
        end

        new_TWT = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(new_seq_chromosome, 1, length(new_seq_chromosome)), v_result, ptr_time)

        if new_TWT < TWT_VALUE
            TWT_VALUE = new_TWT
            best_seq_chromosome = copy(new_seq_chromosome)
            k = 1
        else
            k += 1
        end
    end
    return best_seq_chromosome, TWT_VALUE
end





# ===================================================================
# GA: selection, crossover, and adaptive probabilities
# ===================================================================

# Select top individuals as elite
function select_elite(population, fitness)
    elite_ratio = 0.2
    elite_size = round(Int, elite_ratio * length(population))
    sorted_indices = sortperm(fitness, rev=true)
    elite_indices = sorted_indices[1:elite_size]
    sorted_population = population[elite_indices]
    return sorted_population, sorted_indices[1]
end





# Fitness = 1 / (1 + TWT)
function calculate_fitness1(population)
    population_size = length(population)
    fitness = zeros(Float64, population_size)
    twt_value = zeros(Float64, population_size)
    for i in 1:population_size
        twt_value[i] = population[i][2]
        fitness[i] = 1 / (1 + twt_value[i])
    end
    return fitness
end




# Select one individual via roulette wheel
function select_one(roulette, population)
    r = rand()
    selected_index = findfirst(x -> x >= r, roulette)
    return population[selected_index]
end

# Roulette wheel selection for parent pairs
function roulette_selection(population)
    n = length(population)
    num_parents = 2
    fitness = calculate_fitness1(population)
    total_fitness = sum(fitness)
    probabilities = zeros(Float64, n)
    for i in 1:n
        probabilities[i] = fitness[i] / total_fitness
    end
    roulette = cumsum(probabilities)
    parents = []
    for _ in 1:num_parents
        push!(parents, select_one(roulette, population))
    end
    return parents
end





# ===================================================================
# GA: sequence crossover (order-based crossover)
# ===================================================================

function sequence_crossover(parent1, parent2)
    n = length(parent1)
    cp1 = rand(1:n)
    cp2 = rand(1:n)
    if cp1 > cp2
        cp1, cp2 = cp2, cp1
    end

    cross_section1 = parent1[cp1:cp2]
    cross_section2 = parent2[cp1:cp2]

    child1 = Int[]
    child2 = Int[]
    sorted_child1 = Int[]
    sorted_child2 = Int[]
    sorted_parent1 = Int[]
    sorted_parent2 = Int[]

    start_index = cp2 % length(parent1) + 1
    if start_index == 1
        for i in 1:cp2
            push!(sorted_parent1, parent1[i])
        end
    else
        for i in start_index:length(parent1)
            push!(sorted_parent1, parent1[i])
        end
        for i in 1:cp2
            push!(sorted_parent1, parent1[i])
        end
    end

    if start_index == 1
        for i in 1:cp2
            push!(sorted_parent2, parent2[i])
        end
    else
        for i in start_index:length(parent2)
            push!(sorted_parent2, parent2[i])
        end
        for i in 1:cp2
            push!(sorted_parent2, parent2[i])
        end
    end

    for i in 1:length(sorted_parent2)
        if !(sorted_parent2[i] in cross_section1)
            push!(sorted_child1, sorted_parent2[i])
        end
    end
    append!(sorted_child1, cross_section1)

    for i in (length(sorted_child1)-cp2+1):length(sorted_child1)
        push!(child1, sorted_child1[i])
    end
    for i in 1:(length(sorted_child1)-cp2)
        push!(child1, sorted_child1[i])
    end

    for i in 1:length(sorted_parent1)
        if !(sorted_parent1[i] in cross_section2)
            push!(sorted_child2, sorted_parent1[i])
        end
    end
    append!(sorted_child2, cross_section2)

    for i in (length(sorted_child2)-cp2+1):length(sorted_child2)
        push!(child2, sorted_child2[i])
    end
    for i in 1:(length(sorted_child2)-cp2)
        push!(child2, sorted_child2[i])
    end

    return child1, child2
end





# ===================================================================
# NEH heuristic for initial group sequence
# ===================================================================

function NEH_TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)
    if G < 2
        if G == 1
            sol_NEH_sequence = [1]
        else
            return [1, 2], 0
        end
        TWT_sol = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(sol_NEH_sequence, 1, length(sol_NEH_sequence)), v_result, ptr_time)
        return sol_NEH_sequence, TWT_sol
    end

    sequence_chromosome = zeros(Int, G)
    PT = sum(p, dims=2)
    PT1 = PT[:, 1]
    sol3 = sortperm(PT1)

    for i = 1:G
        sequence_chromosome[i] = sol3[i]
    end

    sol_NEH_sequence = zeros(Int, 2)
    sol_NEH_sequence[1] = sequence_chromosome[1]
    sol_NEH_sequence[2] = sequence_chromosome[2]

    TWT_sol_NEH = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(sol_NEH_sequence, 1, length(sol_NEH_sequence)), v_result, ptr_time)

    sol_NEH_sequence2 = zeros(Int, 2)
    sol_NEH_sequence2[1] = sequence_chromosome[2]
    sol_NEH_sequence2[2] = sequence_chromosome[1]

    TWT_sol_NEH2 = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(sol_NEH_sequence2, 1, length(sol_NEH_sequence2)), v_result, ptr_time)

    if TWT_sol_NEH2 < TWT_sol_NEH
        sol_NEH_sequence = sol_NEH_sequence2
        TWT_sol_NEH = TWT_sol_NEH2
    end

    for k in 3:G
        Seq = zeros(Int64, k, k)
        TWT_Seq = zeros(Int64, k)

        for i in 1:k
            New_sol_NEH = zeros(Int64, length(sol_NEH_sequence))
            for u in 1:length(sol_NEH_sequence)
                New_sol_NEH[u] = sol_NEH_sequence[u]
            end
            insert!(New_sol_NEH, i, sequence_chromosome[k])
            Seq[i, :] = New_sol_NEH
            TWT_Seq[i] = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(New_sol_NEH, 1, length(New_sol_NEH)), v_result, ptr_time)
        end

        min_val, best_index = findmin(TWT_Seq)
        sol_NEH_sequence = zeros(Int, k)
        sol_NEH_sequence = Seq[best_index, :]
        TWT_sol_NEH = min_val
    end

    return sol_NEH_sequence, TWT_sol_NEH
end


# Random group sequence
function Random_solution(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)
    if G < 2
        if G == 1
            sequence_chromosome = [1]
        else
            sequence_chromosome = [1, 2]
        end
    else
        sequence_chromosome = randperm(G)
    end

    ct, C, MK = makespan(p, G, W, mold_to_groups, group_to_mold, sequence_chromosome, ptr_time)

    ct_jobs = zeros(Int64, J)
    for pair in v_result
        job_id = pair[1]
        group_id = pair[2]
        if group_id <= length(ct)
            ct_jobs[job_id] = Int(ct[group_id])
        end
    end

    T = zeros(Int64, J)
    for j in 1:J
        T[j] = ct_jobs[j] - d[j]
        if T[j] < 0
            T[j] = 0
        end
    end

    del_punish = sum(beta[j] * T[j] for j in 1:J)
    return sequence_chromosome, del_punish
end


# Initial population: one NEH solution + random solutions
function initial_solution(population_size, beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)
    population = []

    
    sol_NEH_sequence, TWT_sol_NEH = NEH_TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)
    push!(population, (sol_NEH_sequence, TWT_sol_NEH))

    
    for i in 2:population_size
        sol_Random_sequence, TWT_sol_Random = Random_solution(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time)
        push!(population, (sol_Random_sequence, TWT_sol_Random))
    end

    return population
end





# ===================================================================
# Adaptive crossover/mutation probabilities (AGA)
# pc, pm decrease as individual fitness approaches the best
# ===================================================================

function adaptive_pc_pm(f_i, f_avg, f_max, k1, k2, k3, k4)
    if f_max == f_avg
        return k2, k4
    end

    if f_i >= f_avg
        ratio = (f_max - f_i) / (f_max - f_avg)
        pc = k1 * ratio
        pm = k3 * ratio
    else
        pc = k2
        pm = k4
    end

    pc = clamp(pc, 0.0, 1.0)
    pm = clamp(pm, 0.0, 1.0)

    return pc, pm
end


# ===================================================================
# Main GA + VNS loop with simulated annealing acceptance
# ===================================================================

# GA with VNS mutation, elite preservation, and SA-based acceptance
function GA_VNS(beta, d, p, J, G, W, mold_to_groups, group_to_mold, population, population_size, crossover_prob, mutation_prob, v_result, max_iteration, ptr_time, time_limit; k1=1.0, k2=0.5, k3=1.0, k4=0.5)
    fitness = [1.0 / (1.0 + pop[2]) for pop in population]
    sorted_population, sorted_indice = select_elite(population, fitness)
    best_fitness = fitness[sorted_indice]
    best_TWT = population[sorted_indice][2]
    best_solution = population[sorted_indice][1]

    iteration = 1
    T_para = T_para_tuning
    # 方案 B: 把 Temp 标度降到与 |Δ_fit| 同量级（|Δ_fit| 典型 ~1e-3）
    Temp = T_para * 0.001

    start_time = time()

    while time() - start_time < time_limit
        new_population = []

        for i in 1:length(sorted_population)
            push!(new_population, sorted_population[i])
        end

        while length(new_population) < population_size
            selected_parent = roulette_selection(population)
            seq_parent1 = selected_parent[1][1]
            seq_parent2 = selected_parent[2][1]
            par1_TWT = selected_parent[1][2]
            par2_TWT = selected_parent[2][2]
            par1_fit = 1.0 / (1.0 + par1_TWT)
            par2_fit = 1.0 / (1.0 + par2_TWT)

            
            f_avg = mean([1.0 / (1.0 + pop[2]) for pop in population])
            f_max = maximum([1.0 / (1.0 + pop[2]) for pop in population])
            f_i = min(par1_fit, par2_fit)
            pc, pm = adaptive_pc_pm(f_i, f_avg, f_max, k1, k2, k3, k4)

            if rand() < pc
                seq_child1, seq_child2 = sequence_crossover(seq_parent1, seq_parent2)
            else
                seq_child1 = copy(seq_parent1)
                seq_child2 = copy(seq_parent2)
            end

            if rand() < pm
                new_seq_child1, child1_TWT = VNS(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time, seq_child1)
                new_seq_child2, child2_TWT = VNS(beta, d, p, J, G, W, mold_to_groups, group_to_mold, v_result, ptr_time, seq_child2)
            else
                new_seq_child1 = copy(seq_child1)
                new_seq_child2 = copy(seq_child2)
                child1_TWT = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(new_seq_child1, 1, length(new_seq_child1)), v_result, ptr_time)
                child2_TWT = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(new_seq_child2, 1, length(new_seq_child2)), v_result, ptr_time)
            end

            child1_fit = 1.0 / (1.0 + child1_TWT)
            child2_fit = 1.0 / (1.0 + child2_TWT)

            g = rand()
            sa1 = exp(clamp((child1_fit - par1_fit) / Temp, -50.0, 700.0))
            sa2 = exp(clamp((child2_fit - par2_fit) / Temp, -50.0, 700.0))

            if child1_fit > par1_fit || g <= sa1
                seq_child1 = copy(new_seq_child1)
            end

            if child2_fit > par2_fit || g <= sa2
                seq_child2 = copy(new_seq_child2)
            end

            final_child1_TWT = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(seq_child1, 1, length(seq_child1)), v_result, ptr_time)
            final_child2_TWT = TWT(beta, d, p, J, G, W, mold_to_groups, group_to_mold, reshape(seq_child2, 1, length(seq_child2)), v_result, ptr_time)

            push!(new_population, (seq_child1, final_child1_TWT))
            push!(new_population, (seq_child2, final_child2_TWT))
        end

        population = copy(new_population)
        fitnesses = [1.0 / (1.0 + pop[2]) for pop in population]
        current_best_fitness = maximum(fitnesses)

        if current_best_fitness > best_fitness
            best_idx = argmax(fitnesses)
            best_fitness = current_best_fitness
            best_TWT = population[best_idx][2]
            best_solution = population[best_idx][1]
        end

        sorted_population, sorted_indice = select_elite(population, fitnesses)
        iteration += 1
    end

    return best_solution, best_TWT
end





# ===================================================================
# Vehicle routing: MILP assignment (Gurobi)
# Minimize vehicle fixed cost subject to capacity constraints
# ===================================================================

# ===================================================================
# VLSP: Vehicle Loading Subproblem (MILP, per-group)
# Implements the model described in main.tex Section 4.X (MILP-LT)
# ===================================================================

"""
    VLSP(group_jobs, all_weights, rho, Q; time_limit=60.0, verbose=false)

Mixed Integer Linear Programming model for the Vehicle Loading Subproblem (VLSP)
per group, as described in the paper.

# Arguments
- `group_jobs::Vector{Int}`: list of job indices (1-based) belonging to this group
- `all_weights::Vector{Float64}`: weight of every job (wg[j] for job j)
- `rho::Float64`: fixed cost per activated vehicle
- `Q::Float64`: vehicle capacity (max total weight)
- `time_limit::Float64`: solver time limit in seconds
- `verbose::Bool`: whether to print diagnostic information

# Returns
- `(total_cost, vehicle_count, assignment_vector)`
  - `total_cost`: total vehicle loading cost (rho * activated_vehicles)
  - `vehicle_count`: number of actually used vehicles
  - `assignment_vector`: vector of length `length(group_jobs)` where
    `assignment_vector[i]` is the vehicle index (1-based) assigned to
    the `i`-th job in `group_jobs`
"""
function VLSP(group_jobs::Vector{Int}, all_weights, rho, Q;
              time_limit::Float64=60.0, verbose::Bool=false)

    n_jobs = length(group_jobs)
    if n_jobs == 0
        return 0.0, 0, Int[]
    end

    # Extract weights for jobs in this group
    weights = Float64[all_weights[j] for j in group_jobs]

    # Vehicle count upper bound: min(n_jobs, min_vehicles + 3)
    # min_vehicles is a lower bound based on total weight / capacity
    min_vehicles = ceil(Int, sum(weights) / Q)
    V = min(n_jobs, min_vehicles + 3)

    model = Model(Gurobi.Optimizer)

    if verbose
        println("    [VLSP] 组内作业数=$n_jobs, 车辆上限=$V, 最小所需车辆=$min_vehicles")
        println("    [VLSP] 组内工件总重量=$(round(sum(weights), digits=2)), 车辆容量=$Q, ρ=$rho")
    end

    # Decision variables
    # X[j,v] = 1 if job j (in this group) is assigned to vehicle v
    @variable(model, X[j=1:n_jobs, v=1:V], Bin)
    # γ[v] = 1 if vehicle v is activated (used)
    @variable(model, γ[v=1:V], Bin)

    # Objective: minimize total vehicle activation cost
    # min ρ * Σ_{v∈V} γ_v
    @objective(model, Min, sum(rho * γ[v] for v in 1:V))

    # Constraint (eq:assign): each job must be assigned to exactly one vehicle
    # Σ_{v∈V} X_{j,v} = 1,  ∀j ∈ J_g
    @constraint(model, [j in 1:n_jobs],
        sum(X[j, v] for v in 1:V) == 1)

    # Constraint (eq:link): a job can only be assigned to an activated vehicle
    # X_{j,v} ≤ γ_v,  ∀j ∈ J_g, ∀v ∈ V
    @constraint(model, [j in 1:n_jobs, v in 1:V],
        X[j, v] <= γ[v])

    # Constraint (eq:capacity): total weight on vehicle v ≤ Q * γ_v
    # Σ_{j∈J_g} q_j * X_{j,v} ≤ Q * γ_v,  ∀v ∈ V
    @constraint(model, [v in 1:V],
        sum(weights[j] * X[j, v] for j in 1:n_jobs) <= Q * γ[v])

    # Symmetry-breaking: enforce ordered activation γ_v ≤ γ_{v-1}
    # This cuts symmetric solutions and speeds up solving
    for v in 2:V
        @constraint(model, γ[v] <= γ[v-1])
    end

    set_optimizer_attribute(model, "OutputFlag", 0)
    set_time_limit_sec(model, time_limit)
    set_silent(model)
    optimize!(model)

    status = termination_status(model)

    if status == OPTIMAL || status == TIME_LIMIT || status == FEASIBLE_POINT
        v_cost = objective_value(model)
        vehicle_count = sum(value(γ[v]) for v in 1:V) |> value |> Int

        # Build assignment vector: for each job index in group_jobs,
        # find which vehicle it is assigned to
        assignment_vector = zeros(Int, n_jobs)
        X_val = value.(X)
        for j in 1:n_jobs
            for v in 1:V
                if X_val[j, v] > 0.5
                    assignment_vector[j] = v
                    break
                end
            end
        end
        return v_cost, vehicle_count, assignment_vector
    else
        if verbose
            println("    [VLSP] 警告: 求解状态=$(status)，返回失败值")
        end
        return Inf, 0, zeros(Int, n_jobs)
    end
end

# Backward-compatible wrapper: delegates to VLSP with a single group

function yunshu(J, W, wg, rho, Q; verbose::Bool=false)
    time_limit = W > 0 ? J * W * 0.02 : 60.0
    total_cost, vehicle_count, assignment_vector = VLSP(
        collect(1:J), wg, rho, Q; time_limit=time_limit, verbose=verbose)
    return total_cost, vehicle_count, assignment_vector
end





# ===================================================================
# Perturbation operators for escaping local optima
# ===================================================================

function perturb_sequence(seq; stagnate_limit::Int=5)
    if isempty(seq)
        return seq
    end
    n = length(seq)
    if n < 2
        return seq
    end
    idxs = shuffle(1:n)
    i, j = idxs[1], idxs[2]
    new_seq = copy(seq)
    new_seq[i], new_seq[j] = new_seq[j], new_seq[i]
    return new_seq
end

# Check if two items have similar dimensions (within tolerance)
function is_similar_item(item1, item2; δ_w::Float64=0.1, δ_h::Float64=0.1)
    w1, h1 = item1[1], item1[2]
    w2, h2 = item2[1], item2[2]
    return abs(w1 - w2) < δ_w && abs(h1 - h2) < δ_h
end

# Find all pairs of similar-sized jobs in a sequence
function find_similar_pairs(seq, items; δ_w::Float64=0.1, δ_h::Float64=0.1)
    n = length(seq)
    similar_pairs = Vector{Tuple{Int, Int}}()
    for i in 1:n
        for j in (i+1):n
            job_i = seq[i]
            job_j = seq[j]
            item_i = items[job_i, :]
            item_j = items[job_j, :]
            if is_similar_item(item_i, item_j; δ_w=δ_w, δ_h=δ_h)
                push!(similar_pairs, (i, j))
            end
        end
    end
    return similar_pairs
end

# Swap a pair of similar-dimension jobs (layout-aware perturbation)
function neighborhood_perturb(seq, items, WW, HH; δ_w::Float64=0.1, δ_h::Float64=0.1)
    if isempty(seq)
        return seq, false
    end
    n = length(seq)
    if n < 2
        return seq, false
    end
    similar_pairs = find_similar_pairs(seq, items; δ_w=δ_w, δ_h=δ_h)
    if isempty(similar_pairs)
        return seq, false
    end
    i, j = rand(similar_pairs)
    new_seq = copy(seq)
    new_seq[i], new_seq[j] = new_seq[j], new_seq[i]
    boxes_dict, ansBXY, ran, BinNum, result = packing_by_sequence_aga(items, new_seq, WW, HH)
    if BinNum > 0 && size(result, 1) > 0
        return new_seq, true
    end
    return seq, false
end

# Full perturbation: try neighborhood_perturb first, then random swaps
function perturb_layout_sequence(seq, items, WW, HH; max_attempts::Int=10)
    if isempty(seq)
        return seq, false
    end
    n = length(seq)
    if n < 2
        return seq, false
    end
    original_items = copy(items)
    for attempt in 1:max_attempts
        new_seq = copy(seq)
        success = false
        if attempt == 1
            new_seq, success = neighborhood_perturb(seq, items, WW, HH)
            if success
                return new_seq, true
            end
        end
        idxs = shuffle(1:n)
        i, j = idxs[1], idxs[2]
        new_seq[i], new_seq[j] = new_seq[j], new_seq[i]
        boxes_dict, ansBXY, ran, BinNum, result = packing_by_sequence_aga(original_items, new_seq, WW, HH)
        if BinNum > 0 && size(result, 1) > 0
            return new_seq, true
        end
    end
    return seq, false
end





# ===================================================================
# Core BF-GA integration: packing -> mold assignment -> GA-VNS scheduling -> vehicle routing
# ===================================================================

function BF_GA(J, W_num, w, h, pt, d, beta, ptr_time, wg, seq, WW, HH, rho, Q, alpha)
    items = hcat(w, h)

    
    boxes_dict, ansBXY, ran, BinNum, result = packing_by_sequence_aga(items, seq, WW, HH)

    raw_bin_ids = result[:, 2]
    
    sorted_keys = sort(collect(Set(filter(x -> x > 0, raw_bin_ids))))
    G = length(sorted_keys)
    
    
    if G == 0
        return [], 1e10, 0, [], [], zeros(0, 4), Dict{Int, Int}(), Dict{Int, Vector{Int}}(), 0.0, 0.0
    end
    
    bin_id_map = Dict(old_id => new_id for (new_id, old_id) in enumerate(sorted_keys))

    v_result = [[Int(result[i, 1]), bin_id_map[result[i, 2]]] for i in 1:size(result, 1) if result[i, 2] > 0]

    bin_to_jobs = Dict{Int, Vector{Int}}()
    for pair in v_result
        job_id = pair[1]
        group_id = pair[2]
        if haskey(bin_to_jobs, group_id)
            push!(bin_to_jobs[group_id], job_id)
        else
            bin_to_jobs[group_id] = [job_id]
        end
    end

    p = zeros(G, 4)
    for (group_id, jobs) in bin_to_jobs
        p1 = []
        p3 = []
        for j in jobs
            p[group_id, 2] += pt[j, 2]
            push!(p1, pt[j, 1])
            push!(p3, pt[j, 3])
        end
        p[group_id, 1] = maximum(p1)
        p[group_id, 3] = maximum(p3)
    end
    p[:, 4] .= ptr_time

    
    group_to_mold = Dict{Int, Int}()
    mold_to_groups = Dict{Int, Vector{Int}}()
    mold_load = zeros(W_num)

    sorted_bins = sortperm([p[bin_id, 1] for bin_id in 1:G])
    for bin_id in sorted_bins
        lightest_mold = argmin(mold_load)
        group_to_mold[bin_id] = lightest_mold
        if haskey(mold_to_groups, lightest_mold)
            push!(mold_to_groups[lightest_mold], bin_id)
        else
            mold_to_groups[lightest_mold] = [bin_id]
        end
        mold_load[lightest_mold] += p[bin_id, 1]
    end

    
    mold_assignment_local_search!(
        group_to_mold, mold_to_groups, mold_load, p, G, W_num,
        beta, d, J, v_result, ptr_time
    )

    group_to_mold_remap = group_to_mold
    mold_to_groups_remap = mold_to_groups

    max_iteration = maxIter_tuning
    population_size = popSize_tuning * G
    crossover_prob = 0.8  
    mutation_prob = 0.1   

    ga_time_limit = J * W_num * 0.02

    population = initial_solution(population_size, beta, d, p, J, G, W_num, mold_to_groups_remap, group_to_mold_remap, v_result, ptr_time)

    best_solution, best_TWT = GA_VNS(beta, d, p, J, G, W_num, mold_to_groups_remap, group_to_mold_remap, population, population_size, crossover_prob, mutation_prob, v_result, max_iteration, ptr_time, ga_time_limit; k1=k1_tuning, k2=k2_tuning, k3=k3_tuning, k4=k4_tuning)

    # Group-to-mold local search: re-optimize mold assignment to reduce vehicle cost
    # (consistent with BF_GVNS / BF_IG / BF_VNS to ensure unified search space)
    mold_assignment_local_search!(
        group_to_mold_remap, mold_to_groups_remap, mold_load, p, G, W_num,
        beta, d, J, v_result, ptr_time
    )

    # Per-group VLSP: solve vehicle loading subproblem for each group independently
    # as described in the paper (Section MILP-LT)
    # Inner time tracking: accumulate VLSP solver time (per-group MILP) for outer/inner reporting
    inner_vlsp_start = time()
    total_v_cost = 0.0
    job_to_vehicle = zeros(Int, J)
    global_vehicle_counter = 0
    for group_id in sort(collect(keys(bin_to_jobs)))
        group_jobs = bin_to_jobs[group_id]
        group_time_limit = length(group_jobs) * W_num * 0.02
        g_cost, g_vehicles, g_assignment = VLSP(group_jobs, wg, rho, Q; time_limit=group_time_limit, verbose=false)
        total_v_cost += g_cost
        for (idx, job_id) in enumerate(group_jobs)
            job_to_vehicle[job_id] = g_assignment[idx] + global_vehicle_counter
        end
        global_vehicle_counter += g_vehicles
    end
    inner_vlsp_time = time() - inner_vlsp_start
    # Rebuild v_result with vehicle assignment as third element
    v_result_with_vehicle = [[pair[1], pair[2], job_to_vehicle[pair[1]]] for pair in v_result]

    group_activation_cost = G * alpha
    twt_value = best_TWT
    best_cost = total_v_cost + twt_value + group_activation_cost

    return best_solution, best_cost, G, v_result_with_vehicle, p, group_to_mold, mold_to_groups, total_v_cost, twt_value, job_to_vehicle, inner_vlsp_time
end





# ===================================================================
# Main entry: repeated perturbation + BF_GA search loop
# ===================================================================

function main(filenm)
    J = load(filenm, "JJ")
    W = load(filenm, "WW_num")
    WW = load(filenm, "WW")
    HH = load(filenm, "HH")
    α = load(filenm, "alpha")
    w = load(filenm, "wj")
    h = load(filenm, "hj")
    pt = load(filenm, "pp")
    d = load(filenm, "dd")
    β = load(filenm, "betabeta")
    ptr = load(filenm, "ptr")
    wg = load(filenm, "wg")
    Q = load(filenm, "Q")
    rho = load(filenm, "rho")

    items = hcat(w, h)
    max_time = J * W * 0.5
    start_time = time()

    best_seq = []
    best_G = typemax(Int)
    best_cost = 1e10
    best_v_result = []
    best_p = zeros(0, 0)
    best_group_to_mold = Dict{Int, Int}()
    best_mold_to_groups = Dict{Int, Vector{Int}}()
    best_v_cost = 0.0
    best_tardiness_cost = 0.0
    best_mold_activation_cost = 0.0
    best_job_to_vehicle = zeros(Int, J)
    best_group_sequence = Int[]
    best_stats = nothing
    # Accumulator for inner (VLSP) solver time across all BF_GA calls
    total_inner_vlsp_time = 0.0

    while time() - start_time < max_time
        # PRM(σ★, G★): at most 3 attempts, each based on the current best layout.
        # Strategy 1 (neighborhood-based swap) is tried first; on failure,
        # Strategy 2 (20%--30% partial shuffle) is tried. A Strategy is accepted
        # only if the resulting group count G' does not exceed the current best G★.
        # If all 3 attempts fail, the layout sequence is restored to best_seq.
        if isempty(best_seq)
            perturb_seq = shuffle(1:J)
        else
            base_seq = copy(best_seq)
            perturb_seq = copy(best_seq)
            n = length(perturb_seq)
            accepted = false

            for attempt in 1:3
                # Always re-perturb from the current best layout (not from a
                # previous attempt's perturbed sequence).
                perturb_seq = copy(base_seq)
                if n < 2
                    break
                end

                # --- Strategy 1: Neighborhood-based Perturbation ---
                local_seq, success = neighborhood_perturb(perturb_seq, items, WW, HH)
                if success
                    perturb_seq = local_seq
                    _, _, _, neighborhood_BinNum, _ = packing_by_sequence_aga(
                        items, perturb_seq, WW, HH)
                    if neighborhood_BinNum > 0 && neighborhood_BinNum <= best_G
                        accepted = true
                        break
                    end
                end

                # --- Strategy 2: Random Partial Shuffle (20%--30%) ---
                # Always re-perturb from base_seq (PRM spec).
                perturb_seq = copy(base_seq)
                ratio = rand() * 0.1 + 0.2
                k = max(1, floor(Int, n * ratio))
                idxs = shuffle(1:n)
                swap_idxs = idxs[1:k]
                swap_vals = perturb_seq[swap_idxs]
                shuffle!(swap_vals)
                perturb_seq[swap_idxs] = swap_vals

                _, _, _, shuffle_BinNum, _ = packing_by_sequence_aga(
                    items, perturb_seq, WW, HH)
                if shuffle_BinNum > 0 && shuffle_BinNum <= best_G
                    accepted = true
                    break
                end
                # else: next attempt (re-perturb from base_seq)
            end

            if !accepted
                # All 3 attempts failed: return the original (σ★, G★)
                # (consistent with PRM pseudocode Algorithm~\ref{alg:prm}).
                perturb_seq = copy(best_seq)
            end
        end

        
        
        
        current_group_seq, current_cost, current_G, current_v_result,
        current_p, current_group_to_mold,
        current_mold_to_groups, current_v_cost,
        current_tardiness_cost, current_job_to_vehicle,
        current_inner_vlsp_time = BF_GA(J, W, w, h, pt, d, β, ptr, wg, perturb_seq, WW, HH, rho, Q, α)

        # Accumulate inner VLSP time across all BF_GA iterations
        total_inner_vlsp_time += current_inner_vlsp_time

        # Update best solution: accept only when total cost improves
        # (Revised based on reviewer's comment: removed "|| current_G < best_G" 
        #  to strictly follow the total cost minimization objective)
        if current_cost < best_cost
            best_cost = current_cost
            best_G = current_G
            best_seq = perturb_seq
            best_group_sequence = current_group_seq
            best_v_result = current_v_result
            best_p = current_p
            best_group_to_mold = current_group_to_mold
            best_mold_to_groups = current_mold_to_groups
            best_v_cost = current_v_cost
            best_tardiness_cost = current_tardiness_cost
            best_mold_activation_cost = current_G * α
            best_job_to_vehicle = copy(current_job_to_vehicle)
            best_stats = build_solution_statistics(J, W, WW, HH, w, h, d, β, rho,
                best_group_sequence, best_v_result, best_p, best_group_to_mold, best_mold_to_groups,
                best_v_cost, best_tardiness_cost, best_mold_activation_cost)
        end
    end

    run_time = time() - start_time
    # Return all components of the best solution (revised to address reviewer's comment)
    # inner_time appended at the end so existing positional unpacks (r[1:7], etc.) remain stable
    return (
        run_time,                    # 1  Running time (outer)
        best_seq,                    # 2  Best layout sequence σ*
        best_cost,                   # 3  Best total cost Φ*
        0,                           # 4  Placeholder for compatibility
        best_seq,                    # 5  Layout sequence (copy)
        best_G,                      # 6  Best group count G*
        best_v_result,               # 7  Job-to-group assignment
        best_v_result,               # 8  Assignment (copy)
        best_p,                      # 9  Group processing time matrix
        best_group_to_mold,          # 10 Group-to-machine assignment ψ*
        best_mold_to_groups,         # 11 Machine-to-group mapping
        best_v_cost,                 # 12 Vehicle cost Φ₃
        best_tardiness_cost,         # 13 Tardiness cost (TWT)
        best_mold_activation_cost,   # 14 Mold activation cost (αG)
        best_job_to_vehicle,         # 15 Job-to-vehicle assignment V*
        best_group_sequence,         # 16 Best production sequence π*
        best_stats,                  # 17 Solution statistics
        total_inner_vlsp_time        # 18 Accumulated inner (VLSP) solver time
    )
end




# ===================================================================
# Solution statistics builder and printer
# ===================================================================

# Compute utilization, tardiness, vehicle cost for a solution
function build_solution_statistics(J, W, WW, HH, w, h, d, beta, rho,
    best_seq, best_v_result, best_p, best_group_to_mold, best_mold_to_groups,
    best_v_cost, best_tardiness_cost, mold_activation_cost)

    mold_area = WW * HH
    group_jobs = Dict{Int, Vector{Int}}()
    for item in best_v_result
        if item isa AbstractVector && length(item) >= 2
            job_id = item[1]
            group_id = item[2]
        else
            continue
        end
        if !haskey(group_jobs, group_id)
            group_jobs[group_id] = Int[]
        end
        push!(group_jobs[group_id], job_id)
    end

    mold_utilization = Dict{Int, Float64}()
    group_utilization = Dict{Int, Float64}()
    for (group_id, jobs) in group_jobs
        used_area = sum(w[j] * h[j] for j in jobs; init=0.0)
        group_utilization[group_id] = mold_area > 0 ? used_area / mold_area : 0.0
    end
    for mold in 1:W
        group_ids = get(best_mold_to_groups, mold, Int[])
        mold_utilization[mold] = isempty(group_ids) ? 0.0 : mean(get(group_utilization, group_id, 0.0) for group_id in group_ids)
    end

    vehicle_assignments = Dict{Int, Int}()
    if best_v_result isa AbstractVector
        for item in best_v_result
            if item isa AbstractVector && length(item) >= 3
                job_id = item[1]
                vehicle_id = item[3]
                if vehicle_id isa Number && vehicle_id > 0
                    vehicle_assignments[job_id] = Int(vehicle_id)
                end
            end
        end
    end

    vehicle_count = length(filter(!iszero, unique(values(vehicle_assignments))))

    tardy_jobs = Vector{NamedTuple{(:job_id, :completion_time, :due_date, :tardiness, :penalty), Tuple{Int, Float64, Float64, Float64, Float64}}}()

    if !isempty(best_seq) && !isempty(best_p) && !isempty(best_group_to_mold) && !isempty(best_mold_to_groups)
        seq_vec = best_seq isa AbstractVector ? collect(best_seq) : vec(best_seq)
        ct, _, _ = makespan(best_p, size(best_p, 1), W, best_mold_to_groups, best_group_to_mold, seq_vec, best_p[1, 4])

        for j in 1:J
            group_id = get(Dict(pair[1] => pair[2] for pair in best_v_result), j, 0)
            completion_time = ct[group_id]
            tardiness = max(completion_time - d[j], 0.0)
            penalty = beta[j] * tardiness
            if tardiness > 1e-6
                push!(tardy_jobs, (
                    job_id = j,
                    completion_time = completion_time,
                    due_date = d[j],
                    tardiness = tardiness,
                    penalty = penalty,
                ))
            end
        end
    end

    total_tardy_penalty = sum(item.penalty for item in tardy_jobs; init=0.0)

    return (
        mold_utilization = mold_utilization,
        group_utilization = group_utilization,
        average_mold_utilization = isempty(group_utilization) ? 0.0 : mean(values(group_utilization)),
        vehicle_count = vehicle_count,
        vehicle_cost = best_v_cost,
        mold_activation_cost = mold_activation_cost,
        tardy_jobs = tardy_jobs,
        total_tardy_penalty = total_tardy_penalty,
    )
end

# Print solution statistics
function print_solution_statistics(stats, G, alpha)
    println("  工件组面积利用率:")
    for group_id in sort(collect(keys(stats.group_utilization)))
        println("    工件组 $(group_id): $(round(stats.group_utilization[group_id] * 100, digits=2))%")
    end
    println("  平均工件组面积利用率 = $(round(stats.average_mold_utilization * 100, digits=2))%")
    println("  使用车辆数量 = $(stats.vehicle_count)")
    mold_activation_cost = G * alpha
    println("  成本分解:")
    println("    车辆成本 = $(round(stats.vehicle_cost, digits=2))")
    println("    模台激活成本 = $(round(mold_activation_cost, digits=2)) (G=$G × α=$alpha)")
    println("    拖期惩罚成本 = $(round(stats.total_tardy_penalty, digits=2))")
    cost_sum = stats.vehicle_cost + mold_activation_cost + stats.total_tardy_penalty
    println("    三项合计 = $(round(cost_sum, digits=2))")

    if isempty(stats.tardy_jobs)
        println("  无拖期工件")
    else
        println("  拖期工件数量 = $(length(stats.tardy_jobs))")
        println("  拖期工件明细:")
        for item in stats.tardy_jobs
            println("    工件 $(item.job_id): 完工=$(round(item.completion_time, digits=2)), 交期=$(round(item.due_date, digits=2)), 拖期=$(round(item.tardiness, digits=2)), 费用=$(round(item.penalty, digits=2))")
        end
    end
end



if !@isdefined(SCRIPT_DIR)
    global SCRIPT_DIR = @__DIR__
end
if !@isdefined(INSTANCE_DIR)
    global INSTANCE_DIR = joinpath(dirname(SCRIPT_DIR), "DATA_Instances")
end

# ===================================================================
# Test drivers and entry point
# ===================================================================

# Single instance test: run multiple trials and print statistics
function single_instance_test(filenm; num_runs=5)
    println("=" ^ 70)
    println("PRHBF-AGA 单实例测试 (集成版)")
    println("=" ^ 70)
    println("实例文件: $(basename(filenm))")
    println("运行次数: $num_runs")
    println("=" ^ 70)

    J = load(filenm, "JJ")
    WW_num = load(filenm, "WW_num")
    WW = load(filenm, "WW")
    HH = load(filenm, "HH")
    α = load(filenm, "alpha")
    wg = load(filenm, "wg")
    Q = load(filenm, "Q")
    rho = load(filenm, "rho")

    println("\n实例参数:")
    println("  工件数 J = $J")
    println("  模台数 WW_num = $WW_num")
    println("  模台尺寸 WW × HH = $WW × $HH")
    println("  模台激活成本 α = $α")
    println("  总重量 = $(sum(wg))")
    println("  车辆载量 Q = $Q, 固定成本 ρ = $rho")
    println("  最小车辆数 = $(ceil(Int, sum(wg)/Q))")

    check_out = zeros(num_runs)
    check_time = zeros(num_runs)

    for op in 1:num_runs
        println("\n--- 第 $op/$num_runs 次运行 ---")
        try
            r = main(filenm)
            run_time, best_solution, best_cost, best_fitness, best_ran, best_bin_num, best_result = r[1:7]
            stats = r[end-1]
            check_out[op] = best_cost
            check_time[op] = run_time
            println("  组数 G = $best_bin_num")
            println("  成本 = $best_cost")
            println("  运行时间 = $(round(run_time, digits=2))s")
            if stats !== nothing
                print_solution_statistics(stats, best_bin_num, α)
            end
        catch e
            println("  错误: $e")
            check_out[op] = NaN
            check_time[op] = NaN
        end
    end

    println("\n" * "=" ^ 70)
    println("统计结果")
    println("=" ^ 70)

    valid_costs = filter(!isnan, check_out)
    valid_times = filter(!isnan, check_time)

    if !isempty(valid_costs)
        println("  成本: 最小=$(minimum(valid_costs)), 最大=$(maximum(valid_costs)), 平均=$(round(mean(valid_costs), digits=2))")
        println("  时间: 最小=$(round(minimum(valid_times), digits=2))s, 最大=$(round(maximum(valid_times), digits=2))s, 平均=$(round(mean(valid_times), digits=2))s")
    else
        println("  所有运行都失败了！")
    end

    println("=" ^ 70)
    return (costs=check_out, times=check_time)
end




function batch_test(; num_runs=5)
    data_dir = INSTANCE_DIR
    results_dir = joinpath(SCRIPT_DIR, "results")
    if !isdir(results_dir)
        mkdir(results_dir)
    end

    all_files = String[]
    for f in readdir(data_dir)
        if endswith(f, ".jld2")
            push!(all_files, joinpath(data_dir, f))
        end
    end
    all_files = sort(all_files)

    timestamp = Dates.format(now(), "yyyy-mm-dd_HHMMSS")
    output_file = joinpath(results_dir, "AGA_results_$timestamp.csv")

    println("=" ^ 70)
    println("PRHBF-AGA 批量测试")
    println("=" ^ 70)
    println("数据目录: $data_dir")
    println("共找到 $(length(all_files)) 个数据集文件")
    println("每个实例运行 $num_runs 次")
    println("结果输出: $output_file")
    println("=" ^ 70)

    results = []
    total = length(all_files)

    for (idx, filenm) in enumerate(all_files)
        println("\n[$idx/$total] 正在测试: $(basename(filenm))")

        check_out = zeros(num_runs)
        check_time = zeros(num_runs)
        check_vehicle_count = fill(NaN, num_runs)
        check_mold_utilization = fill(NaN, num_runs)
        check_tardy_penalty = fill(NaN, num_runs)
        check_vehicle_cost = fill(NaN, num_runs)
        check_mold_activation_cost = fill(NaN, num_runs)

        for op in 1:num_runs
            try
                r = main(filenm)
                run_time, best_tal, best_cost, best_bin_num = r[1:4]
                stats = r[end-1]
                check_out[op] = best_cost
                check_time[op] = run_time
                if stats !== nothing
                    check_vehicle_count[op] = stats.vehicle_count
                    check_mold_utilization[op] = stats.average_mold_utilization
                    check_tardy_penalty[op] = stats.total_tardy_penalty
                    check_vehicle_cost[op] = stats.vehicle_cost
                    check_mold_activation_cost[op] = stats.mold_activation_cost
                end
            catch e
                println("  运行 $op 错误: $e")
                check_out[op] = NaN
                check_time[op] = NaN
                check_vehicle_count[op] = NaN
                check_mold_utilization[op] = NaN
                check_tardy_penalty[op] = NaN
                check_vehicle_cost[op] = NaN
                check_mold_activation_cost[op] = NaN
            end
        end

        val_cost = mean(filter(!isnan, check_out))
        val_time = mean(filter(!isnan, check_time))
        avg_vehicle_count = mean(filter(!isnan, check_vehicle_count))
        avg_mold_utilization = mean(filter(!isnan, check_mold_utilization))
        avg_tardy_penalty = mean(filter(!isnan, check_tardy_penalty))
        avg_vehicle_cost = mean(filter(!isnan, check_vehicle_cost))
        avg_mold_activation_cost = mean(filter(!isnan, check_mold_activation_cost))

        push!(results, (instance=basename(filenm),
            (Symbol("cost$i") => check_out[i] for i in 1:num_runs)...,
            avg_cost=val_cost, avg_time=val_time,
            (Symbol("vehicle_count$i") => check_vehicle_count[i] for i in 1:num_runs)...,
            avg_vehicle_count=avg_vehicle_count,
            (Symbol("util$i") => (isnan(check_mold_utilization[i]) ? NaN : round(Int, check_mold_utilization[i] * 100)) for i in 1:num_runs)...,
            avg_mold_utilization=(isnan(avg_mold_utilization) ? NaN : round(Int, avg_mold_utilization * 100)),
            (Symbol("tardy$i") => check_tardy_penalty[i] for i in 1:num_runs)...,
            avg_tardy_penalty=avg_tardy_penalty))

        mold_util_pct = isnan(avg_mold_utilization) ? NaN : round(Int, avg_mold_utilization * 100)
        println("  -> 平均成本: $(round(val_cost, digits=2)), 平均时间: $(round(val_time, digits=2))s")
        println("     车辆成本: $(round(avg_vehicle_cost, digits=2)), 模台激活成本: $(round(avg_mold_activation_cost, digits=2)), 拖期惩罚: $(round(avg_tardy_penalty, digits=2))")
        println("     平均车辆数: $(round(avg_vehicle_count, digits=2)), 平均利用率: $mold_util_pct%")
        cost_sum = avg_vehicle_cost + avg_tardy_penalty + avg_mold_activation_cost
        println("     成本验证: 车辆+拖期+模台 = $(round(cost_sum, digits=2)) vs 目标 = $(round(val_cost, digits=2))")
    end

    df = DataFrame(results)
    CSV.write(output_file, df)
    println("\n" * "=" ^ 70)
    println("批量测试完成！")
    println("结果已保存到: $output_file")
    println("=" ^ 70)

    return df
end




if abspath(PROGRAM_FILE) == @__FILE__
    if length(ARGS) == 0
        batch_test()  
    elseif ARGS[1] == "single"
        filenm = length(ARGS) >= 2 ? ARGS[2] : joinpath(INSTANCE_DIR, "S_10_2_1.jld2")
        num_runs = length(ARGS) >= 3 ? parse(Int, ARGS[3]) : 5
        single_instance_test(filenm; num_runs=num_runs)
    elseif ARGS[1] == "batch"
        num_runs = length(ARGS) >= 2 ? parse(Int, ARGS[2]) : 5
        batch_test(; num_runs=num_runs)
    elseif ARGS[1] == "help"
        println()
    else
        println("未知命令: $(ARGS[1])")
        println("输入 'julia PRHBF_AGA_Integrated.jl help' 查看帮助")
    end
end